<?php
// This file was auto-generated from sdk-root/src/data/rekognition/2016-06-27/paginators-1.json
return [ 'pagination' => [ 'ListCollections' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'CollectionIds', ], 'ListFaces' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'Faces', ], ],];
